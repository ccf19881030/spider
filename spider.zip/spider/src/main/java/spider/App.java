package spider;

/**
 * Hello world!
 *
 */

import java.io.*;
import java.net.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class App  {

    public static void main(String argv[]) {

        URL url = null;
        URLConnection urlconn = null;
        BufferedReader br = null;
        PrintWriter pw = null;
        try {
            url = new URL("http://www.shicimingju.com/chaxun/list/29694.html");
            urlconn = url.openConnection();
            pw = new PrintWriter(new FileWriter("poem.txt"), true);
            br = new BufferedReader(new InputStreamReader(
                    urlconn.getInputStream()));
            String buf = null;
            StringBuffer sb = new StringBuffer();
            while ((buf = br.readLine()) != null) {
                sb.append(buf);
            }
            buf = sb.toString();

            String title_regex = "(?<=<h1 class=\"shici-title\">)(.*)(?=</h1>)";
            Pattern title_p = Pattern.compile(title_regex);

            String person_regex = "(?<=<div class=\"shici-info\">)(.*)</a>               </div>";
            Pattern person_p = Pattern.compile(person_regex);

            String peom_regex =  "(?<=<div class=\"shici-content\">)(.*)<div class=\"shici-mark\">";
            Pattern peom_p = Pattern.compile(peom_regex);

            Matcher title_buf = title_p.matcher(buf);
            Matcher person_buf = person_p.matcher(buf);
            Matcher peom_buf = peom_p.matcher(buf);

            if (title_buf.find()) {
                pw.println(title_buf.group());
                System.out.println(title_buf.group());
            }
            if (person_buf.find()) {
                String temp = person_buf.group().replaceAll("<a href=\"/chaxun/zuozhe/6.html\">", " ").replaceAll(
                        "</a>               </div>", "").replaceAll(
                        " ", "");
                pw.println(temp);
                System.out.println(temp);
            }
            if (peom_buf.find()) {
                String temp = peom_buf.group().replaceAll("<br>", "\r\n").replaceAll(
                        "               </div>                <div class=\"shici-mark\">", "").replaceAll(
                        " ", "");
                pw.println(temp);
                System.out.println(temp);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            pw.close();
        }

    }


}

